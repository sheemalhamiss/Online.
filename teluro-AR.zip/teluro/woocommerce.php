<?php

get_header();
teluro_theme()->get( 'main-woo' )->render();
get_footer();
