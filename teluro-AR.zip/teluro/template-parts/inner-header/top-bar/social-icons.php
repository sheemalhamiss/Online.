<div data-colibri-id="10-h21" class="style-23 style-local-10-h21 position-relative h-element">
  <div class="d-flex flex-wrap h-social-icons justify-content-lg-end justify-content-md-end justify-content-center">
    <?php $component = \ColibriWP\Theme\View::getData( "component" );  $component->printIcons(); ?>
  </div>
</div>
