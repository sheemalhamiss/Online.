<div data-colibri-id="10-h25" class="page-title style-552 style-local-10-h25 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div class="h-page-title__outer style-552-outer style-local-10-h25-outer">
    <div class="h-global-transition-all">
      <?php teluro_page_title(array (
        'tag' => 'h1',
      )); ?>
    </div>
  </div>
</div>
